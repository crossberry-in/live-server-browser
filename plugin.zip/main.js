"use strict";(()=>{var y={$schema:"https://acode.app/schema/plugin/v0.1.0.json",id:"acode.plugin",name:"cb-live",main:"main.js",version:"1.0.0",repository:"https://github.com/Acode-Foundation/acode-plugin.git",icon:"icon.png",minVersionCode:290,license:"MIT",keywords:[],price:0,author:{name:"crossberry",email:"",github:"",website:"https://crossberry.pages.dev"}};var w=class{async init(f){this.$page=f,this.baseUrl="https://your-plugin-base-url.com";let r=document.createElement("style");r.id="preview-plugin-style",r.textContent=`
      .preview-toggle {
        background-color: rgba(163, 96, 96, 0.478);
        border: white;
        color: #fff;
        text-align: center;
        top: 50%;
        height: 20px;
        position: fixed;
        width: 70px;
        rotate: 90deg;
        right: -10px;
        border-radius: 12px;
        box-shadow: 0 4px 10px rgba(120, 91, 91, 0.531);
        cursor: pointer;
        z-index: 99999;
        transition: transform 0.2s ease-in-out;
      }
      .preview-toggle:active { transform: scale(0.95); }

      .flod {
        background-color: #1a1a1a;
        height: 260px;
        width: 260px;
        position: absolute;
        top: 50px;
        left: 50px;
        border-radius: 12px;
        box-shadow: 0 4px 15px rgba(0, 0, 0, 0.5);
        font-family: sans-serif;
        cursor: default;
        touch-action: none;
        display: none;
        z-index: 99998;
        resize: both;
        min-width: 200px;
        min-height: 120px;
        max-width: 90vw;
        max-height: 90vh;
        overflow: hidden;
      }
      /* === Bigger resize grip === */
      .flod::after {
        content: "";
        position: absolute;
        right: 2px;
        bottom: 2px;
        width: 16px;   /* default ~10px \u2192 increased by 5px */
        height: 16px;
        background: linear-gradient(135deg, transparent 50%, #888 50%);
        cursor: se-resize;
        pointer-events: none; /* keeps native resize working */
      }

      .move{
        height: 20px;
        width: 100%;
        background-color: #222;
        border-bottom: 1px solid #444;
        display: flex;
        align-items: center;
        padding: 0 5px;
        box-sizing: border-box;
        cursor: grab;
        position:relative;
        top:-20px;
      }
      #flod-head {
        height: 30px;
        width: 100%;
        background-color: #222;
        border-bottom: 1px solid #444;
        display: flex;
        align-items: center;
        padding: 0 5px;
        box-sizing: border-box;
        cursor: grab;
      }
      #flod-head:active { cursor: grabbing; }
      #url-input-container { flex-grow: 1; margin-left: 4px; }
      #flod-head input {
        width: 100%;
        height: 22px;
        border: none;
        border-radius: 4px;
        padding: 0 8px;
        font-size: 11px;
        background-color: #333;
        color: #fff;
      }
      #flod-head input:focus { outline: none; background-color: #444; }

      .nav-button {
        background: none;
        border: none;
        cursor: pointer;
        display: flex;
        align-items: center;
        justify-content: center;
        width: 20px;
        height: 20px;
        margin: 0 2px;
      }
      .nav-button svg {
        fill: #ccc;
        width: 16px;
        height: 16px;
        transition: fill 0.2s ease-in-out;
      }
      .nav-button:hover svg { fill: #fff; }
      .nav-button:disabled svg { fill: #666; cursor: not-allowed; }

      #iframe-wrapper {
        position: absolute;
        top: 30px;
        left: 0;
        width: 100%;
        height: calc(100% - 30px);
        overflow-y: auto;
        -webkit-overflow-scrolling: touch;
      }
      #iframe-wrapper::before {
        content: "\u2193 Pull to Refresh";
        display: block;
        text-align: center;
        color: #888;
        font-size: 12px;
        padding: 4px;
        transform: translateY(-100%);
      }
      #preview-body {
        width: 100%;
        height: 100%;
        border: none;
        background-color: #fff;
      }
    `,document.head.appendChild(r);let l=document.createElement("div");l.className="preview-toggle",l.textContent="Preview",document.body.appendChild(l);let t=document.createElement("div");t.className="flod",t.id="flod",t.innerHTML=`
      <div id="flod-head">
        <button id="back-btn" class="nav-button" title="Go Back">
          <svg viewBox="0 0 24 24"><path d="M15.41 16.59L10.83 12l4.58-4.59L14 6l-6 6 6 6z"/></svg>
        </button>
        <button id="forward-btn" class="nav-button" title="Go Forward">
          <svg viewBox="0 0 24 24"><path d="M8.59 16.59L13.17 12 8.59 7.41 10 6l6 6-6 6z"/></svg>
        </button>
        <button id="refresh-btn" class="nav-button" title="Refresh Page">
          <svg viewBox="0 0 24 24"><path d="M17.65 6.35C16.2 4.9 14.21 4 12 4c-4.42 
          0-7.99 3.58-7.99 8s3.57 8 7.99 
          8c3.73 0 6.84-2.55 7.73-6h-2.08c-.82 
          2.33-3.04 4-5.65 4-3.31 0-6-2.69-6-6s2.69-6 
          6-6c1.84 0 3.48.83 4.59 2.15L14 
          12h5.5V6.5z"/></svg>
        </button>
        <div id="url-input-container">
          <input type="url" id="url-input" placeholder="Enter URL" />
        </div>
        <div class="move"></div>
      </div>
      <div id="iframe-wrapper">
        <iframe id="preview-body" src="https://crossberry.pages.dev" frameborder="0"></iframe>
      </div>
    `,document.body.appendChild(t);let s=t.querySelector("#url-input"),c=t.querySelector("#preview-body"),p=t.querySelector("#flod-head"),k=t.querySelector("#back-btn"),L=t.querySelector("#forward-btn"),W=t.querySelector("#refresh-btn"),u=t.querySelector("#iframe-wrapper");s.value="https://crossberry.pages.dev";let i=[s.value],n=0,b=e=>{c.src=e,s.value=e},h=()=>{k.disabled=n<=0,L.disabled=n>=i.length-1};l.addEventListener("click",()=>{t.style.display=t.style.display==="none"||t.style.display===""?"block":"none",t.style.display==="block"&&h()}),s.addEventListener("keydown",e=>{if(e.key==="Enter"){e.preventDefault();let o=s.value.trim();o&&(/^https?:\/\//i.test(o)||(o="https://"+o),i=i.slice(0,n+1),i.push(o),n++,b(o),h())}}),k.addEventListener("click",()=>{n>0&&(n--,b(i[n]),h())}),L.addEventListener("click",()=>{n<i.length-1&&(n++,b(i[n]),h())}),W.addEventListener("click",()=>c.contentWindow.location.reload());let E=0,g=!1;u.addEventListener("touchstart",e=>{u.scrollTop===0&&(E=e.touches[0].clientY,g=!0)},{passive:!0}),u.addEventListener("touchmove",e=>{if(!g)return;e.touches[0].clientY-E>60&&(g=!1,c.contentWindow.location.reload())},{passive:!0}),u.addEventListener("touchend",()=>{g=!1}),setInterval(()=>{try{c.contentWindow.location.reload()}catch{}},3e4);let v=!1,z=0,Y=0,S=e=>{if(e.target.closest("#url-input-container")||e.target.closest(".nav-button"))return;e.preventDefault(),v=!0;let o=t.getBoundingClientRect(),m=e.type.startsWith("touch")?e.touches[0].clientX:e.clientX,a=e.type.startsWith("touch")?e.touches[0].clientY:e.clientY;z=m-o.left,Y=a-o.top,t.style.transition="none",p.style.cursor="grabbing"},B=e=>{if(!v)return;e.preventDefault();let o=e.type.startsWith("touch")?e.touches[0].clientX:e.clientX,m=e.type.startsWith("touch")?e.touches[0].clientY:e.clientY,a=o-z,x=m-Y;a=Math.max(0,Math.min(a,window.innerWidth-t.offsetWidth)),x=Math.max(0,Math.min(x,window.innerHeight-t.offsetHeight)),t.style.left=a+"px",t.style.top=x+"px"},q=()=>{v=!1,p.style.cursor="grab"};p.addEventListener("mousedown",S),document.addEventListener("mousemove",B),document.addEventListener("mouseup",q),p.addEventListener("touchstart",S,{passive:!1}),document.addEventListener("touchmove",B,{passive:!1}),document.addEventListener("touchend",q)}async destroy(){document.querySelector(".preview-toggle")?.remove(),document.querySelector("#flod")?.remove(),document.querySelector("#preview-plugin-style")?.remove()}};if(window.acode){let d=new w;acode.setPluginInit(y.id,async(f,r)=>{d.baseUrl=f,await d.init(r)}),acode.setPluginUnmount(y.id,()=>{d.destroy()})}})();
